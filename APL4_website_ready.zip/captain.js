let myPlayers=JSON.parse(localStorage.getItem("apl4_myplayers")||"[]");
function login(){if(document.getElementById("user").value==="captain"&&document.getElementById("pass").value==="apl4"){document.getElementById("login").classList.add("hidden");document.getElementById("dash").classList.remove("hidden");render()}else alert("Demo login: captain / apl4");}
function logout(){location.reload()}
function showAdd(){document.getElementById("addBox").classList.toggle("hidden")}
function addPlayer(){let n=document.getElementById("pname").value.trim(),j=document.getElementById("jersey").value,r=document.getElementById("role").value,v=document.getElementById("village").value;if(!n)return alert("Player name डालें");myPlayers.push({name:n,jersey:j,role:r,village:v});localStorage.setItem("apl4_myplayers",JSON.stringify(myPlayers));document.getElementById("pname").value="";document.getElementById("jersey").value="";render()}
function render(){document.getElementById("myPlayers").innerHTML=myPlayers.length?myPlayers.map((p,i)=>`<div class="playerrow"><span><b>${p.name}</b><br><small class="muted">${p.role} • #${p.jersey}</small></span><button class="secondary" onclick="removePlayer(${i})">Remove</button></div>`).join(""):`<p class="muted">अभी कोई player नहीं है।</p>`}
function removePlayer(i){myPlayers.splice(i,1);localStorage.setItem("apl4_myplayers",JSON.stringify(myPlayers));render()}
function saveTeam(){alert("Demo में data save हो गया। Online version में यही data Supabase database में जाएगा।")}
