# APL 4 Website
This package is a working mobile-first prototype based on the supplied APL 4 requirements.

## Included
- index.html: public APL website
- captain.html: captain login/dashboard demo
- scorer.html: scorer/live scoring demo
- schema.sql: Supabase database starting schema
- style.css / JS files

## Demo
Captain login: captain / apl4

## To make it truly online
1. Create a free Supabase project.
2. Run schema.sql in Supabase SQL Editor.
3. Create captain Auth users.
4. Add RLS policies mapping each captain user to one team.
5. Put Supabase URL/key in the JS integration.
6. Deploy this folder to GitHub Pages or Cloudflare Pages.

The supplied PDF specifies Supabase Auth/RLS, team/player registration, separate scorer system, and future YouTube Live + live score presentation.
