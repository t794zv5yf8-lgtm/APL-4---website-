let runs=0,w=0,balls=0,history=[];
function draw(){document.getElementById("runs").textContent=runs+"/"+w;document.getElementById("ov").textContent=Math.floor(balls/6)+"."+(balls%6)+" overs";document.getElementById("ball").value=Math.floor(balls/6)+" / "+(balls%6)}
function addRun(n){history.push([runs,w,balls]);runs+=n;balls++;draw()}
function wicket(){history.push([runs,w,balls]);w++;balls++;draw()}
function extra(n){history.push([runs,w,balls]);runs+=n;draw()}
function undo(){let x=history.pop();if(x){[runs,w,balls]=x;draw()}}
draw();
